var newarray = [];
var emailId;
var MessageDetails;
var mailarray = [];
const initForwardStyle = () => {
    var forwardMenuItem = document.createElement("button");
    forwardMenuItem.textContent = "Forward Mail";
    forwardMenuItem.id = "sortbutton";
    forwardMenuItem.style = 'margin-top:4%;background-color:rgba(188, 229, 235, 0.836);border-radius: 12px;border-width:0px;width: 90px;height: 22px;'
    forwardMenuItem.addEventListener('mouseover', function() {
        forwardMenuItem.style.boxShadow = '1px 1px 5px 0 rgba(0,0,0,0.24), 1px 1px 5px 0 rgba(0,0,0,0.19)';
    });
    forwardMenuItem.addEventListener('mouseout', function() {
        forwardMenuItem.style.boxShadow = 'none';
    });
    forwardMenuItem.setAttribute('title', 'Forward All mail for myself');
    forwardMenuItem.addEventListener('click', async function() {
        token = await chrome.runtime.sendMessage('authorization');
        initelem = {
            method: 'GET',
            async: true,
            headers: {
                Authorization: 'Bearer ' + token,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            'contentType': 'json'
        };
        const UserData = await fetch('https://www.googleapis.com/oauth2/v2/userinfo?access_token=' + token);
        const UserDetails = await UserData.json();
        emailId = UserDetails.email;
        //const MessageData = await fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/messages?includeSpamTrash=true&maxResults=501&q=is%3Ainbox', initelem);
        const MessageData = await fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/messages?includeSpamTrash=true&maxResults=501&q=in%3Atrash', initelem);
        //const MessageData = await fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/messages?maxResults=500', initelem);
        MessageDetails = await MessageData.json();
        MessageDetails.messages.forEach(element => {
            newarray.push(element.id);
        });
        for (let i = 0; i < newarray.length; i++) {
            const mailId = await fetch('https://gmail.googleapis.com/gmail/v1/users/'+ emailId +'/messages/'+newarray[i],initelem);
           // const mailId = await fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/messages/' + newarray[i] + '?format=raw', initelem);
            const mailDetails = await mailId.json();
            const toHeaderIndex = mailDetails.payload.headers.findIndex(header => header.name.toLowerCase() === 'to');
            if (toHeaderIndex !== -1) {
                mailDetails.payload.headers[toHeaderIndex].value = emailId;
            }
            const filteredHeaders = mailDetails.payload.headers.filter(header => header.name.toLowerCase() !== 'cc' && header.name.toLowerCase() !== 'bcc');
            mailDetails.payload.headers = filteredHeaders; // Update the headers array
            const rawMailData = await fetch('https://gmail.googleapis.com/gmail/v1/users/'+ emailId +'/messages/'+newarray[i]+'?format=raw', initelem);
            var rawMailDetails = await rawMailData.json();
            mailDetails.raw = rawMailDetails.raw; // Add raw content to the mailDetails
           // console.log(mailDetails.raw)
            //console.log(rawMailDetails.raw)
            mailarray.push(mailDetails)
            console.log(mailarray)
            //console.log(mailarray[0].payload.headers[27].name)
        }
        for (let i = 0; i < mailarray.length; i++) {
           // console.log(i)
            const requestBody = {
                raw: mailarray[i].raw,
            };
           // console.log(requestBody)
            const response = await sendEmails(emailId, requestBody);
            console.log('Email sent:', response);
        }
    });
    return forwardMenuItem;
}


const sendEmails = async (emailId, requestBody) => {
    const token = await chrome.runtime.sendMessage('authorization');
    const requestOptions = {
        method: 'POST',
        headers: {
            Authorization: 'Bearer ' + token,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
    };
    const response = await fetch('https://gmail.googleapis.com/gmail/v1/users/'+emailId+'/messages/send', requestOptions);
    console.log(response)
    return response.json();
};

const initForwardExtraStyling = (forwardelem) => {
    var fordvelem3 = document.createElement("div");
    fordvelem3.classList.add('.FI');
    fordvelem3.appendChild(initForwardStyle());
    forwardelem.appendChild(fordvelem3);
}


const initForwardTemplate = () => {
    let forwardinterval = setInterval(function() {
        let forwardelem = document.querySelector('.gb_9d.gb_7d.bGJ');
        if (forwardelem) {
            clearInterval(forwardinterval);
            initForwardExtraStyling(forwardelem);
        }
    }, 100);
}


const init = async () => {
    initForwardTemplate();
}


const main = async () => {
    await init();
}

main();