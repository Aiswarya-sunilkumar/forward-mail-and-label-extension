//const searchSVG = `<svg aria-labelledby="title desc" role="img" id="search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 19.9 19.7" stroke-width="2" width="20" height="20"><g class="search-path"  fill="white" stroke="#000"><path stroke-linecap="square" d="M18.5 18.3l-5.4-5.4"/><circle cx="8" cy="8" r="7"/></g></svg>`;
const searchSVG = `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0,0,256,256" width="20px" height="20px" fill-rule="nonzero"><g fill="#38e6d2" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><g transform="scale(5.12,5.12)"><path d="M21,3c-9.39844,0 -17,7.60156 -17,17c0,9.39844 7.60156,17 17,17c3.35547,0 6.46094,-0.98437 9.09375,-2.65625l12.28125,12.28125l4.25,-4.25l-12.125,-12.09375c2.17969,-2.85937 3.5,-6.40234 3.5,-10.28125c0,-9.39844 -7.60156,-17 -17,-17zM21,7c7.19922,0 13,5.80078 13,13c0,7.19922 -5.80078,13 -13,13c-7.19922,0 -13,-5.80078 -13,-13c0,-7.19922 5.80078,-13 13,-13z"></path></g></g></svg>`;
var newarray = [];
var labelInputDiv;
var initelem;
var token;
var labelMenuItem
const initLabelStyle = () => {
    labelMenuItem = document.createElement("div");
    labelMenuItem.setAttribute('class', 'dropdown');
    
    var labelButton = document.createElement("div");
    labelButton.innerHTML = searchSVG;
    labelButton.setAttribute('title','You can search and find label names here');
    labelButton.setAttribute('class', 'dropbtn');
    labelButton.addEventListener('click',async function() {
        token = await chrome.runtime.sendMessage('authorization');
                    initelem = {
                        method: 'GET',
                        async: true,
                        headers: {
                            Authorization: 'Bearer ' + token,
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                    'contentType': 'json'
                };
                const UserData = await fetch('https://www.googleapis.com/oauth2/v2/userinfo?access_token=' + token);
                const UserDetails = await UserData.json();
                var emailId = UserDetails.email;
                labelEmail(emailId, initelem);
               
                document.getElementById("myDropdown").classList.toggle("show");
                
                //  var dropdown1 = document.getElementById("myDropdown");
                // if (dropdown1.classList.contains("show")) {
                //     dropdown1.classList.remove("show");
                // } else {
                //     dropdown1.classList.add("show");
                // } 
              
            });
    labelMenuItem.appendChild(labelButton);

    labelInputDiv = document.createElement("div");
    labelInputDiv.setAttribute('class', 'dropdown-content');
    labelInputDiv.setAttribute('id', 'myDropdown');
    labelInputDiv.classList.add('hide');
    labelMenuItem.appendChild(labelInputDiv);
 
    var labelInput = document.createElement("input");
    labelInput.setAttribute('type', 'text');
    labelInput.setAttribute('placeholder', 'search label..');
    labelInput.setAttribute('id', 'myInput');
    labelInput.addEventListener('keyup', function() {
        filterFunction();
    });
    labelInputDiv.appendChild(labelInput);


    window.onclick = function(event) {
        console.log(event.target)
        if (!event.target.matches('#myInput') && !event.target.matches('circle')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
                var openDropdown = dropdowns[i];
                if (openDropdown.classList.contains('show')) {
                    openDropdown.classList.remove('show');
                 }
             }
        }
    }

    return labelMenuItem;
}



function filterFunction() {
    let input = document.getElementById("myInput");
    let div = document.getElementById("myDropdown");
    let filter = input.value.toLowerCase();
    console.log(filter)
    let a = div.querySelectorAll("a.lnksearchkey");
    for (let i = 0; i < a.length; i++) {
        let txtValue = a[i].textContent.toLowerCase();
        if (txtValue.indexOf(filter) >= 0) {
            console.log(txtValue, txtValue.indexOf(filter))
            document.querySelector('a.lnksearchkey[data-value=' + txtValue + ']').classList.remove('hide-element');
        } else {
            document.querySelector('a.lnksearchkey[data-value=' + txtValue + ']').classList.add('hide-element');
        }
    }
}



//const getlabelName = async () => {
    // chrome.storage.local.get(["token"]).then((result) => {
    //     let init = {
    //         method: 'GET',
    //         async: true,
    //         headers: {
    //             Authorization: 'Bearer ' + result.token,
    //             'Content-Type': 'application/json'
    //         },
    //         'contentType': 'json'
    //     };
        // chrome.storage.local.get(["userId"]).then((result) => {
        //     var emailId = result.userId;
        //     labelEmail(emailId, init);
        // });
   // });


//    token = await chrome.runtime.sendMessage('authorization');
//                     initelem = {
//                         method: 'GET',
//                         async: true,
//                         headers: {
//                             Authorization: 'Bearer ' + token,
//                             'Content-Type': 'application/json',
//                             'Accept': 'application/json'
//                         },
//                     'contentType': 'json'
//                 };
//                 chrome.storage.local.get(["userId"]).then((result) => {
//                     var emailId = result.userId;
//                     labelEmail(emailId, initelem);
//                 });
//}



function labelEmail(emailId, initelem) {
    fetch('https://gmail.googleapis.com/gmail/v1/users/' + emailId + '/labels', initelem)
        .then((response) => response.json())
        .then(function(data) {
            data.labels.forEach(element => {
                newarray.push(element.name);
            });

            var labelOption = document.createElement("a");
            labelOption.innerHTML = '&nbsp;';
            labelInputDiv.appendChild(labelOption);

            for (let index = 0; index < newarray.length; index++) {
                var labelOption = document.createElement("a");
                labelOption.classList.add('lnksearchkey');
                labelOption.setAttribute('data-value', newarray[index].toLowerCase());
                labelOption.addEventListener('click', function() {
                    var typeText = document.querySelector('input[aria-label="Search in mail"]');
                    typeText.value = "label:" + newarray[index];
                    var searchIcon = document.querySelector('[aria-disabled="true"]');
                    searchIcon.click();
                });
                labelOption.innerHTML = newarray[index];
                labelInputDiv.appendChild(labelOption);
            }
            labelInputDiv = "";
        });
}



const initExtraStyling = (elem) => {
    var dvelem3 = document.createElement("div");
    dvelem3.classList.add('aAw');
    dvelem3.classList.add('FgKVne');
    dvelem3.appendChild(initLabelStyle());
    elem.appendChild(dvelem3);
}



const initLabelTemplate = () => {
    var interval = setInterval(function() {
        var elem = document.querySelector('.aAw.FgKVne');
        if (elem) {
            clearInterval(interval);
            initExtraStyling(elem);
        }
    }, 100);
}



const init = async () => {
    initLabelTemplate();
}


const main = async () => {
    await init();
}
 
main();
